package com.example.apple.pre_can;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText a1,a2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a2 = (EditText) findViewById(R.id.pass);
        a1 = (EditText) findViewById(R.id.idnumber) ;

        Button b1 = (Button)findViewById(R.id.login);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               String id =String.valueOf(a1.getText());
                String pass =String.valueOf(a2.getText());
                String ad="ADMIN";
                if (id.equals(ad) == true && pass.equals(ad) == true) {

                    gotostudent();

                } else {

                    Toast.makeText(getApplicationContext(), "Please Enter", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    public void gonextapp(View view)
    {
        Intent i = new Intent(this,Register.class);
        startActivity(i);
    }
    public  void gotostudent()
    {
        Intent su = new Intent(this,Student.class);
        startActivity(su);
    }



}
